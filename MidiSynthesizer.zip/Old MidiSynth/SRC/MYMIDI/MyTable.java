package mymidi;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.PopupMenuListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.border.BevelBorder;
import java.awt.event.*;
import java.util.Vector;

public class MyTable extends JTable implements MouseListener,PopupMenuListener
 {
 	private TableModel tableModel;
 	private JPopupMenu popup;
 	public static final int EDITABLE = 100;
 	public static final int NONEDITABLE = 200;
 	private int modelType;
 	private Vector columns;
 	private static Vector bufferData;
 	
 	static
 	 {
 	 	bufferData = new Vector();
 	 }
 	
 	private JMenuItem insert,delete,cut,copy,paste;
 	
	private MyTable(Vector data,Vector columns, int modelType)
	 {
		this.modelType = modelType;
		this.columns = columns;
			
		this.popup = new JPopupMenu();
		popup.setLightWeightPopupEnabled(true);
	 	popup.setBorder(new BevelBorder(BevelBorder.RAISED));
 		popup.addPopupMenuListener(this);
 		
 		super.addMouseListener(this); 	
		super.setAutoResizeMode(AUTO_RESIZE_OFF);
		super.setCellSelectionEnabled(true);
		
		if(modelType==EDITABLE)
		 constructEditableTable(data,columns);
		 
		else
		 constructNonEditableTable(data,columns);
		 
		super.setModel(tableModel);		 
	 }

	public static MyTable createEditableTable(Vector data, Vector columns)
	 {
	 	MyTable mt = new MyTable(data,columns,EDITABLE);
	 	return mt;
	 }
	
	public static MyTable createNonEditableTable(Vector data, Vector columns)
	 {
	 	MyTable mt = new MyTable(data,columns,NONEDITABLE);
	 	return mt;
	 }
	
	private void constructEditableTable(Vector data,Vector columns)
	 {
		tableModel = new DefaultTableModel(data,columns);

		cut = new JMenuItem("Cut");
		cut.addActionListener(new ActionListener()
		 {
		 	public void actionPerformed(ActionEvent event)
		 	 {
		 	 	tableListeners(event);
		 	 }
		 });
		 
		addPopupMenu(cut);
		
		copy = new JMenuItem("Copy");
		copy.addActionListener(new ActionListener()
		 {
		 	public void actionPerformed(ActionEvent event)
		 	 {
		 	 	tableListeners(event);
		 	 }
		 });
		 
		addPopupMenu(copy);

		paste = new JMenuItem("Paste");
		paste.addActionListener(new ActionListener()
		 {
		 	public void actionPerformed(ActionEvent event)
		 	 {
		 	 	tableListeners(event);
		 	 }
		 });
		 
		addPopupMenu(paste);

		insert = new JMenuItem("Insert");
		insert.addActionListener(new ActionListener()
		 {
		 	public void actionPerformed(ActionEvent event)
		 	 {
		 	 	tableListeners(event);
		 	 }
		 });
		 
		addPopupMenu(insert);
		
		delete = new JMenuItem("Delete");
		delete.addActionListener(new ActionListener()
		 {
		 	public void actionPerformed(ActionEvent event)
		 	 {
		 	 	tableListeners(event);
		 	 }
		 });
		 
		addPopupMenu(delete);
	 }
	
	private void constructNonEditableTable(Vector data,Vector columns)
	 {
	 	tableModel = new AbstractModel(data,columns);
	 } 
	 
	public void setTable(Vector data) 
	 {
	 	if(modelType==EDITABLE)
	 	 tableModel = new DefaultTableModel(data,columns);
	 	
	 	else
	 	  tableModel = new AbstractModel(data,columns);
	 	  
	 	 super.setModel(tableModel);
	 }
	
	private void tableListeners(ActionEvent event)
	 {
	 	if(event.getSource()==cut)
	 	 {
	 	 	int row = super.getSelectedRow();
	 	 	int col = super.getSelectedColumn();
	 	 	
	 	 	int nRows = super.getSelectedRowCount();
	 	 	int nCols = super.getSelectedColumnCount();
	 	 	bufferData.clear();
	 	 	
	 	 	for(int i=row;i<row+nRows;i++)
	 	 	 {
	 	 	 	Vector v = new Vector();
	 	 	 	
	 	 	 	for(int j=col;j<col+nCols;j++)
	 	 	 	 {
	 	 	 	 	v.addElement((String)super.getValueAt(i,j));
	 	 	 	 	super.setValueAt("",i,j);
	 	 	 	 }
	 	 	 	  
	 	 	 	bufferData.addElement(v);
	 	 	 }	 	 	
	 	 }
	 	 
	 	if(event.getSource()==copy)
	 	 {
	 	 	int row = super.getSelectedRow();
	 	 	int nRows = super.getSelectedRowCount();
	 	 	int col = super.getSelectedColumn();
	 	 	int nCols = super.getSelectedColumnCount();
	 	 	
	 	 	bufferData.clear();
	 	 	
	 	 	for(int i=row;i<row+nRows;i++)
	 	 	 {
	 	 	 	Vector v = new Vector();
	 	 	 	
	 	 	 	for(int j=col;j<col+nCols;j++)
	 	 	 	 	v.addElement((String)super.getValueAt(i,j));
	 	 	 	  
	 	 	 	bufferData.addElement(v);
	 	 	 }	 	 	
	 	 }
		
	 	if(event.getSource()==paste)
	 	 {
	 	 	int row = super.getSelectedRow();
	 	 	int col = super.getSelectedColumn();
			int n = bufferData.size();
				 	 	
	 	 	for(int i=row;i<row+n;i++)
	 	 	 {
	 	 	 	Vector v = (Vector)bufferData.elementAt(i-row);
	 	 	 	for(int j=col;j<col+v.size();j++)
	 	 	 	 {
	 	 	 	 	//if(i<super.getColumnCount() && j<super.getRowCount())
	 	 	 	 	 super.setValueAt((String)v.elementAt(j-col),i,j);
	 	 	 	 }	
	 	 	 	 	
	 	 	 }	 	 	
	 	 }
		
	 	if(event.getSource()==insert)
	 	 {
	 	 	int row = super.getSelectedRow();
	 	 	int n = super.getSelectedRowCount();
	 	 	int cols = super.getColumnCount();
	 	 	
	 	 	for(int i=row;i<row+n;i++)
	 	 	 {
	 	 	 	Vector v = new Vector();
	 	 	 	
	 	 	 	for(int j=0;j<cols;j++)
	 	 	 	 v.addElement("");
	 	 	 	  
	 	 	 	((DefaultTableModel)tableModel).insertRow(i,v);
	 	 	 }
	 	 }
	 	 
	 	if(event.getSource()==delete)
	 	 {
	 	 	int option = JOptionPane.showConfirmDialog(this,"Do you want to delete selected rows","Confirm delete",JOptionPane.YES_NO_OPTION);

	 	 	if(option==JOptionPane.YES_OPTION)
	 	 	{
		 	 	int row = super.getSelectedRow();
		 	 	int n = super.getSelectedRowCount();
		 	 	int cols = super.getColumnCount();
		 	 	
		 	 	for(int i=row+n-1;i>=row;i--)
		 	 	 ((DefaultTableModel)tableModel).removeRow(i);
		 	 	 
		 	 	int rows = super.getRowCount();
		 	 	
		 	 	if(rows==0)
		 	 	 {
		 	 	 	Vector data = new Vector();
		 	 	 	
		 	 	 	for(int i=0;i<4;i++)
		 	 	 	 {
		 	 	 	 	Vector v = new Vector();
		 	 	 	 	
		 	 	 	 	for(int j=0;j<cols;j++)
		 	 	 	 	  v.addElement("");
		 	 	 	 	data.addElement(v);
		 	 	 	 }
		 	 	 	
		 	 	    setTable(data); 
		 	 	 	 
		 	 	 } 
			}	 	 	
	 	 } 
	 } 
	 
	public Vector getDataVector()
	 {
	 	Vector dataVector = new Vector();
	 	
	 	if(modelType==EDITABLE)
	 	 dataVector = ((DefaultTableModel)super.getModel()).getDataVector();
	 	
	 	else
	 	 {
	 	 	int rows = tableModel.getRowCount();
	 	 	int cols = tableModel.getColumnCount();
	 	 	
	 	 	for(int i=0;i<rows;i++)
	 	 	 {
	 	 	 	Vector v = new Vector();
	 	 	 	
	 	 	 	for(int j=0;j<cols;j++)
	 	 	 	 {
	 	 	 	 	Object val = tableModel.getValueAt(i,j);
	 	 	 		v.addElement(val); 	
	 	 	 	 }
	 	 	 	 
	 	 	 	dataVector.addElement(v); 
	 	 	 }
	 	 } 
	 	 
	 	return dataVector; 
	 }
	 
	public void addPopupMenu(JMenuItem item)
	 {
	 	popup.add(item);
	 }

	public void mousePressed(MouseEvent event)
 	 {
 	 	checkPopup(event);
 	 }
 	
 	public void mouseClicked(MouseEvent event)
 	 {
 	 	checkPopup(event);
 	 } 
 	 
 	public void mouseEntered(MouseEvent event)
 	 {
 	 	
 	 }
 	
 	public void mouseExited(MouseEvent event)
 	 {
 	 	
 	 }
 	
 	public void mouseReleased(MouseEvent event)
 	 {
 	 	checkPopup(event);
 	 }
 	
 	private void checkPopup(MouseEvent event)
 	 {
 	 	if(event.isPopupTrigger() && modelType==EDITABLE)
 	 	 {
 	 	 	popup.show(this,event.getX(),event.getY());
 	 	 }
 	 }
 	
 	public void popupMenuWillBecomeVisible(PopupMenuEvent e) 
 	 {
 	
 	 }
 	
 	public void popupMenuWillBecomeInvisible(PopupMenuEvent e) 
 	 {

 	 }

	public void popupMenuCanceled(PopupMenuEvent e) 
 	 {
 	 	popup.setVisible(false);
 	 }   	 
	
	class AbstractModel extends AbstractTableModel
	 {
	 	Vector data;
	 	Vector columns;
	 	
	 	public AbstractModel(Vector data, Vector columns)
	 	 {
	 	 	this.data = data;
	 	 	this.columns = columns;
	 	 }
	 	 
	 	public int getColumnCount()
	 	  {
	 	  	return columns.size(); 	  	
	 	  }
	 	  
	 	public int getRowCount()
	 	   {
	 	   	 if(data == null)
	 	   	  return 0;
	 	   	 else
	 	   	  return data.size() ;
	 	   }
	 	   
	 	public Object getValueAt(int row,int column)
	 	    {
	 	    	Vector v = (Vector)data.elementAt(row);
	 	    	return ((String)v.elementAt(column));
	 	    }
	 	    
	 	public String getColumnName(int column) 
	 	    {
	 	    	return (String)columns.elementAt(column); 
	 	    }
		
		public boolean isCellEditable(int row,int col)
		 {
		 	return false;
		 }
	 }	 
 }
