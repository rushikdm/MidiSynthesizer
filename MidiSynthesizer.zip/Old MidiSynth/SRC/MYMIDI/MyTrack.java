package mymidi;

import javax.sound.midi.*;
import java.util.Vector;
import java.io.*;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.Color;

public class MyTrack
 {
 	Vector data;
 	Data instruments;
 	Data notes;
 	public Data timings;
 	Data volumes;
    Sequencer sequencer;
 	public MyTrack()
 	 {
 	 	setupMidi();
 	    setupData();
 	 }
 	 
 	 private void setupMidi()
 	  {
 	  	    Synthesizer synthesizer = null;

 	      try {
            if (synthesizer == null) {
                if ((synthesizer = MidiSystem.getSynthesizer()) == null) {
                    System.out.println("getSynthesizer() failed!");
                    return;
                }
            } 
            synthesizer.open();
            sequencer = MidiSystem.getSequencer();
        } catch (Exception ex) { ex.printStackTrace(); return; }
        
	 }
 	
	 
 	private void setupData()
 	 {
		String[] instStr = {"Piano","Harpsi Chord","Accordion","Nylon Str Guitar","Fretless Bass","Cello","Synth Strings 1","Bassoon","Shanai","END"};
		int[] instValues = {0,6,20,24,35,42,50,70,111};
		
		instruments = new Data(instStr, instValues);
		
		String[] noteStr = {"P--","Da--","DA--","Ni--","NI--","S-","Re-","RE-","Ga-","GA-","Ma-","MA-","P-","Da-","DA-","Ni-","NI-","S","Re","RE","Ga","GA","Ma","MA","P","Da","DA","Ni","NI","S*","Re*","RE*","Ga*","GA*","Ma*","MA*","P*","Da*","DA*","Ni*","NI*","S**","Re**","RE**","Ga**","GA**","Ma**"};
		int[] noteValues = {44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90};
		
		notes = new Data(noteStr, noteValues);
		
		String[] timeStr = {"4","2","1","7/8","3/4","2/3","1/2","1/3","1/4","1/8"};
		int[] timeValues = {96,48,24,21,18,16,12,8,6,3};
		
		timings = new Data(timeStr, timeValues);
		
		String[] volStr = {"0","1","2","3","4","5","6","7"};
		int[] volValues = {0,13,26,39,52,65,78,91};
 	 	
 	 	volumes = new Data(volStr, volValues);
 	 } 
 	 
	public void setData(Vector data)
	 {
	 	this.data = data;
	 }
	 
	public boolean check()
	 {
	 	return true;
	 }
	 
	private Sequence getSequence(int pitch, int speed)
	 {
	 	Track track=null;
	 	Sequence seq=null;
	 	int resolution = 30 * speed/100;
	 	try
	 	{
	 		seq = new Sequence(Sequence.PPQ, resolution);
			track = seq.createTrack();
	 	}
		catch(Exception ex) { ex.printStackTrace(); }
		
	 	Vector v = (Vector)data.elementAt(0);
	 	String inst = (String)v.elementAt(0);
	 	String note = (String)v.elementAt(1);
	 	String tm = (String)v.elementAt(2);
	 	String vol = (String)v.elementAt(3);
	 	
	 	int instInt = instruments.getValue(inst);
	 	int noteInt = notes.getValue(note);
	 	int timeInt = timings.getValue(tm);
	 	int volInt = volumes.getValue(vol);

	 	try
	 	 {
	        ShortMessage message = new ShortMessage();
	        message.setMessage(ShortMessage.PROGRAM_CHANGE, instInt,0);
	        MidiEvent event = new MidiEvent(message, 0);
	        track.add(event);
         }
       catch (Exception ex) { ex.printStackTrace(); }
	 	
	 	long time=1;
	 	
 	 	try
 	 	 {
	 	 	ShortMessage message1 = new ShortMessage();
	 	 	message1.setMessage(ShortMessage.NOTE_ON, noteInt + pitch, volInt);
	 	 	MidiEvent event1 = new MidiEvent(message1, time);
	        track.add(event1);
	        time+=(long)timeInt;
	        
	        ShortMessage message2 = new ShortMessage();
	 	 	message2.setMessage(ShortMessage.NOTE_OFF, noteInt + pitch, volInt);
	        MidiEvent event2 = new MidiEvent(message2, time);
	        track.add(event2);
         }
       catch (Exception ex) { ex.printStackTrace(); }
	 	
	 	for(int i=1;i<data.size();i++)
	 	 {
	 	 	Vector vect = (Vector)data.elementAt(i);
	 	 	String newInst = (String)vect.elementAt(0);
		 	note = (String)vect.elementAt(1);
		 	tm = (String)vect.elementAt(2);
		 	vol = (String)vect.elementAt(3);

			if(newInst=="END")
			 return seq;
	 	 	
	 	 	if(!newInst.equals(inst))
	 	 	 {
	 	 	 	if(newInst.equals("") || newInst==null)
	 	 	 	 {
	 	 	 	 	
	 	 	 	 }
	 	 	 	
	 	 	 	else
	 	 	 	{
			 	try
			 	 {
			        ShortMessage message = new ShortMessage();
			        message.setMessage(ShortMessage.PROGRAM_CHANGE, instruments.getValue(newInst),0);
			        MidiEvent event = new MidiEvent(message, time);
			        track.add(event);
			        inst = newInst;
		         }
		         
		       catch (Exception ex) { ex.printStackTrace(); }
		       }
	 	 	 }
			
			if(note.equals("") || note==null)
			 {
				
			 }
			
			else
	 		  noteInt = notes.getValue(note);
	 		
	 		if(tm.equals("") || tm==null)
	 		 {
	 		 	
	 		 }
	 		 
	 		 else
	 		  timeInt = timings.getValue(tm);
	 		
	 		if(vol.equals("") || vol==null)
	 		 {
	 		 	
	 		 }
	 		
	 		else 
	 		  volInt = volumes.getValue(vol);
			
	 	 	try
	 	 	 {
		 	 	ShortMessage message1 = new ShortMessage();
		 	 	message1.setMessage(ShortMessage.NOTE_ON, noteInt + pitch, volInt);
		 	 	MidiEvent event1 = new MidiEvent(message1, time);
		        track.add(event1);
		        time+=(long)timeInt;
		        
		        ShortMessage message2 = new ShortMessage();
		 	 	message2.setMessage(ShortMessage.NOTE_OFF, noteInt + pitch, volInt);
		        MidiEvent event2 = new MidiEvent(message2, time);
		        track.add(event2);
	         }
	       catch (Exception ex) { ex.printStackTrace(); }
	 	 	 
	 	 }
	 	 
	 	 return seq;
	 } 
	
	public void play(int pitch, int speedVal, int start)
	 {
           Sequence sequence = getSequence(pitch, 100);

        try {
        		long length = sequence.getMicrosecondLength();
        		length = length / 100 * start;
        		sequencer.open();
       			sequencer.setSequence(sequence);
       			sequencer.setMicrosecondPosition(length);
       			sequencer.setTempoFactor((float)(speedVal/100.0));
            } 
            catch (Exception ex) { ex.printStackTrace(); }
			
			sequencer.start();
	 } 

	public void stop()
	 {
	 	sequencer.stop();
	 }
	 
	public void save(int pitch, int speedVal)
	 {
	 	Sequence seq = getSequence(pitch, speedVal);

        try {
            File file = new File(System.getProperty("user.dir"));
            JFileChooser fc = new JFileChooser(file);
            fc.setFileFilter(new javax.swing.filechooser.FileFilter() {
                public boolean accept(File f) {
                    if (f.isDirectory()) {
                        return true;
                    }
                    return false;
                }
                public String getDescription() {
                    return "Save as .mid file.";
                }
            });
            if (fc.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
                saveMidiFile(fc.getSelectedFile(), seq);
            }
        } catch (SecurityException ex) { 
            JOptionPane.showMessageDialog(null,"Error in saving the file!","Error",JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } catch (Exception ex) { 
            ex.printStackTrace();
        }

	 } 
	 
     public void saveMidiFile(File file, Sequence sequence) {
        try {
            int[] fileTypes = MidiSystem.getMidiFileTypes(sequence);
            if (fileTypes.length == 0) {
                System.out.println("Can't save sequence");
            } else {
                if (MidiSystem.write(sequence, fileTypes[0], file) == -1) {
                    throw new IOException("Problems writing to file");
                } 
            }
        } catch (SecurityException ex) { 
            JOptionPane.showMessageDialog(null,"Error in saving the file!","Error",JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) { 
            ex.printStackTrace(); 
        }
    }
    
   public void open(MyTable table)
    {
    	Sequence seq = null;
    	
        try {
            File file = new File(System.getProperty("user.dir"));
            JFileChooser fc = new JFileChooser(file);
            fc.setFileFilter(new javax.swing.filechooser.FileFilter() {
                public boolean accept(File f) {
                    if (f.isDirectory()) {
                        return true;
                    }
                    return false;
                }
                public String getDescription() {
                    return "Open .mid files.";
                }
            });
            if (fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                	seq = MidiSystem.getSequence(fc.getSelectedFile());
            }
        } catch (SecurityException ex) { 
            JOptionPane.showMessageDialog(null,"Error in saving the file!","Error",JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } catch (Exception ex) { 
            ex.printStackTrace();
        }
    	
    	Vector data = new Vector();
    	Vector vec = new Vector();
    	
    	Track[] tracks = seq.getTracks();
    	Track track = tracks[0];

	 	MidiEvent event = track.get(0);
	 	ShortMessage message = (ShortMessage)event.getMessage();
	 	int data1 = message.getData1();
    	
    	if(message.getCommand()==ShortMessage.PROGRAM_CHANGE)
    	 vec.addElement(instruments.getString(data1));

	 	event = track.get(1);
	 	long tick1 = event.getTick();
	 	message = (ShortMessage)event.getMessage();
	 	data1 = message.getData1();
	 	int data2 = message.getData2();

	 	event = track.get(2);
	 	long tick2 = event.getTick();
	 	String tmStr = timings.getString((int)(tick2-tick1));
	 	String ntStr = notes.getString(data1);
	 	String vlStr = volumes.getString(data2);
	 	
	 	message = (ShortMessage)event.getMessage();
    	
	 	vec.addElement(ntStr);
	 	vec.addElement(tmStr);
	 	vec.addElement(vlStr);
    	
    	data.addElement(vec);
		boolean check=false;
    	
    	int i=3;
    	while(i<track.size()-1)
    	 {
		 	MidiEvent event1 = track.get(i);
		 	ShortMessage message1 = (ShortMessage)event1.getMessage();
    	 	
	    	if(message1.getCommand()==ShortMessage.PROGRAM_CHANGE)
	    	 {
	    	 	check = true;
	    	 	vec = new Vector();
	    	 	vec.addElement(instruments.getString(message1.getData1()));
	    	 	i++;
	    	 }
	    	
	    	else 
	    	 {
	    	 	if(!check)
	    	 	 {
	    	 	 	vec = new Vector();
	    	 	 	vec.addElement("");
	    	 	 }
	    	 	 
			 	tick1 = event1.getTick();
			 	data1 = message1.getData1();
			 	data2 = message1.getData2();
	    	 	
	    	 	i=i+1;	
			 	event1 = track.get(i);
			 	tick2 = event1.getTick();
			 	message1 = (ShortMessage)event1.getMessage();
		    	
		    	if(!ntStr.equals(notes.getString(data1)))
		    	 {
		    	 	ntStr = notes.getString(data1);
		    	 	vec.addElement(ntStr);
		    	 }
			 	  
				
				else
				 vec.addElement("");
				 
		    	if(!tmStr.equals(timings.getString((int)(tick2-tick1))))
		    	 {
		    	 	tmStr = timings.getString((int)(tick2-tick1));
			 	    vec.addElement(tmStr);
		    	 }

				
				else
				 vec.addElement("");
				 
			 	if(!vlStr.equals(volumes.getString(data2)))
			 	 {
			 	 	vlStr = volumes.getString(data2);
			 	 	vec.addElement(vlStr);
			 	 }
			 	  
				
				else
				 vec.addElement("");
				 
			 	data.addElement(vec);
			 	
	    	 	check = false;
	    	 	i++;
	    	 } 	
    	 }
    	 
    	 Vector v = new Vector();
    	 v.addElement("END");
    	 v.addElement("");
    	 v.addElement("");
    	 v.addElement("");
    	 data.addElement(v);     	 
    	 
    	 for(i=0;i<500;i++)
    	  {
    	  	v = new Vector();
    	  	
    	  	for(int j=0;j<4;j++)
    	  	 v.addElement("");
    	  	
    	  	data.addElement(v); 
    	  }
    	 
    	table.setTable(data);
    	setTableRenderer(table);
     }
    
    public MyTable getTable()
     {
	 	Vector columns = new Vector();
	 	columns.addElement("Instrument");
	 	columns.addElement("Note");
	 	columns.addElement("Timing");
	 	columns.addElement("Volume");
		
		Vector tableData = new Vector();
		for(int i=0;i<1000;i++)
		 {
		 	Vector v = new Vector();
		 	
		 	for(int j=0;j<4;j++)
		 	 v.addElement("");
		 	 
		 	tableData.addElement(v);
		 }
     	
     	MyTable table = MyTable.createEditableTable(tableData, columns);
     	setTableRenderer(table);
     	
     	return table;
     } 	 
     
    private void setTableRenderer(MyTable table)
     {
     	setColumn(table, "Instrument", instruments.getStrArray(), new Color(225,225,230));
     	setColumn(table, "Note", notes.getStrArray(),  new Color(255,225,230));
     	setColumn(table, "Timing", timings.getStrArray(), new Color(225,225,230));
     	setColumn(table, "Volume", volumes.getStrArray(),  new Color(255,225,230));
     }
	
	private void setColumn(MyTable table, String name, String[] array, Color color)
	 {
 		JComboBox comboBox = new JComboBox(array);
		
		TableColumn column = table.getColumn(name);
		column.setCellEditor(new DefaultCellEditor(comboBox));
        
        DefaultTableCellRenderer columnRenderer = new DefaultTableCellRenderer();
        columnRenderer.setBackground(color);
        columnRenderer.setToolTipText("Click for Combo Box");
        column.setCellRenderer(columnRenderer);		
	 }
	 
	class Data
	 {
	 	String[] strArray;
	 	int[] values;
	 	
	 	public Data(String[] str, int[] values)
	 	 {
	 	 	this.strArray = str;
	 	 	this.values = values;
	 	 }
	 	
	 	public String[] getStrArray()
	 	 {
	 	 	return strArray;
	 	 }
	 	
	 	public int[] getIntArray()
	 	 {
	 	 	return values;
	 	 } 
	 	
	 	public String getString(int value) 
	 	 {
		 	String result = "";
		 	
		 	for(int i=0;i<values.length;i++)
		 	 {
		 	 	if(value==values[i])
		 	 	 {
		 	 	 	result = strArray[i];
		 	 	 	break;
		 	 	 }
		 	 	 
		 	 }
		 	
		 	return result; 
	 	 	
	 	 }
	 	
	 	public int getValue(String s)
	 	 {
		 	int result = -1;
		 	
		 	for(int i=0;i<values.length;i++)
		 	 {
		 	 	if(s.equals(strArray[i]))
		 	 	 {
		 	 	 	result = values[i];
		 	 	 	break;
		 	 	 }
		 	 	 
		 	 }
		 	
		 	return result; 
	 	 	
	 	 }
	 }  	
 }
