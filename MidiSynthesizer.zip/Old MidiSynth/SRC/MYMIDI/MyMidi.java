package mymidi;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.border.BevelBorder;
import java.awt.event.*;
import java.awt.*;
import java.util.Vector;
import javax.swing.border.*;

public class MyMidi
 {
 	JFrame frame = new JFrame("Midi Synthesizer and Composer");
 	Container container = frame.getContentPane();
	MyTable table;
	JButton play;
	JButton open;
	JButton save;
	JButton calculate;
	MyTrack track;
	JSlider slider;
	JSlider speed;
	JSlider begin;
	JLabel label;
	JTextField numField;
	private JMenuItem goAt;
	
	public MyMidi()
	 {
	 	initialise();

		Box left = Box.createVerticalBox();
		left.add(Box.createVerticalStrut(10));
		left.add(new JScrollPane(table));
		
		Box right = Box.createVerticalBox();
		right.add(Box.createVerticalStrut(10));
		right.add(slider);

		right.add(Box.createVerticalStrut(10));
		right.add(speed);

		right.add(Box.createVerticalStrut(10));
		right.add(begin);
		right.add(Box.createVerticalStrut(10));

		JPanel panel = new JPanel();
 	 	panel.setBorder(new TitledBorder(new EtchedBorder(),"Play / Save / Open"));
		
		Box vbox = Box.createVerticalBox();
		vbox.add(Box.createVerticalStrut(10));
		vbox.add(play);
		vbox.add(Box.createVerticalStrut(10));
		vbox.add(save);
		vbox.add(Box.createVerticalStrut(10));
		vbox.add(open);
		vbox.add(Box.createVerticalStrut(10));
		
 	 	panel.add(vbox,BorderLayout.CENTER);
		right.add(panel);

		panel = new JPanel();
 	 	panel.setBorder(new TitledBorder(new EtchedBorder(),"Timing"));
		
		Box hbox = Box.createHorizontalBox();
		hbox.add(new JLabel("Enter No: "));
		hbox.add(Box.createHorizontalStrut(5));
		hbox.add(numField);
		
		vbox = Box.createVerticalBox();
		vbox.add(hbox);
		vbox.add(Box.createVerticalStrut(15));
		vbox.add(label);
		vbox.add(Box.createVerticalStrut(15));
		vbox.add(calculate);
		
 	 	panel.add(vbox,BorderLayout.CENTER);
		right.add(panel);
		right.add(Box.createVerticalStrut(20));
		
		Box total = Box.createHorizontalBox();
		total.add(Box.createHorizontalStrut(50));
		total.add(left);
		total.add(Box.createHorizontalStrut(20));
		total.add(right);
		total.add(Box.createHorizontalStrut(50));
		total.add(Box.createHorizontalGlue());
		
		container.add(total);
		frame.pack();
		frame.setVisible(true);
		
	 }
	 
    private void initialise()
	 {
	 	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 	frame.setBounds(20,20,500,400);
	 	
	 	track = new MyTrack();
		
		table = track.getTable();

		play = new JButton("Play");
		addALFor(play);
		
		 
		save = new JButton("Save");
		addALFor(save);
		
		open = new JButton("Open");
		addALFor(open);

		calculate = new JButton("Calculate");
		addALFor(calculate);

		slider = new JSlider(-5,5,0);
		slider.setMinorTickSpacing(1);
		slider.setSnapToTicks(true);
		slider.setPaintLabels(true);
		slider.setPaintTicks(true);

        TitledBorder tb = new TitledBorder(new EtchedBorder());
        tb.setTitle("Pitch = 0");
        slider.setBorder(tb);

		speed = new JSlider(50,150,100);
		speed.setMinorTickSpacing(10);
		speed.setSnapToTicks(true);
		speed.setPaintLabels(true);
		speed.setPaintTicks(true);

        TitledBorder tb1 = new TitledBorder(new EtchedBorder());
        tb1.setTitle("Speed = 100");
        speed.setBorder(tb1);
		
		slider.addChangeListener(new ChangeListener()
		{
			public void stateChanged(ChangeEvent e)
			 {
			 	sliderListener(e);
			 }
		});

		speed.addChangeListener(new ChangeListener()
		{
			public void stateChanged(ChangeEvent e)
			 {
			 	sliderListener(e);
			 }
		});
		
		begin = new JSlider(0,100,0);
		begin.setMinorTickSpacing(1);
		begin.setSnapToTicks(true);
		begin.setPaintLabels(true);
		begin.setPaintTicks(true);

        TitledBorder tb2 = new TitledBorder(new EtchedBorder());
        tb2.setTitle("Start = 0");
        begin.setBorder(tb2);

		begin.addChangeListener(new ChangeListener()
		{
			public void stateChanged(ChangeEvent e)
			 {
			 	sliderListener(e);
			 }
		});
	
	   numField = new JTextField(4);
	   label = new JLabel("  ");
	   
	   goAt = new JMenuItem("Go to");
	   
	   goAt.addActionListener(new ActionListener()
	    {
	    	public void actionPerformed(ActionEvent e)
	    	 {
	    	 	positionSlider();
	    	 }
	    });
	    
	   table.addPopupMenu(goAt);
	}
	
	private void sliderListener(ChangeEvent event)
	 {
        JSlider slid = (JSlider) event.getSource();
        int value = slid.getValue();
        TitledBorder tb = (TitledBorder) slid.getBorder();
        String s = tb.getTitle();
        tb.setTitle(s.substring(0, s.indexOf('=')+1) + " " + s.valueOf(value));
        slid.repaint();
	 }
	 
	private void addALFor(JButton button)
	 {
		button.addActionListener(new ActionListener()
		 {
		 	public void actionPerformed(ActionEvent event)
		 	 {
		 	 	actionListeners(event);
		 	 }
		 });
	 }	

    private void actionListeners(ActionEvent event)
     {
     	if(event.getSource()==play)
     	 {
     	 	boolean bool = (play.getText()).equals("Play");
     	 	
		 	if(bool)
		 	 {
	     	 	int pitchVal = slider.getValue();
	     	 	int speedVal = speed.getValue();
	     	 	int start = begin.getValue();
				play.setText("Stop");	
	     	 	track.setData(table.getDataVector());
	     	 	track.play(pitchVal, speedVal, start);
	     	 }	
	
			else
			 {
			 	System.out.println("Stop");
			 	track.stop();
			 	play.setText("Play");
			 }
     	 
     	 }
     	
     	if(event.getSource()==save)
     	 {
     	 	int speedVal = speed.getValue();
     	 	track.setData(table.getDataVector());
     	 	track.save(slider.getValue(), speedVal);
     	 } 
     	
     	if(event.getSource()==open)
     	 {
     	 	track.open(table);
     	 } 
     	
     	if(event.getSource()==calculate)
     	 {
     	 	Vector data = table.getDataVector();
     	 	Vector v = (Vector)data.elementAt(0);
    	 	double time = (double)track.timings.getValue((String)v.elementAt(2));
     	 	double totalTime = time;

     	 	for(int i=1;i<data.size();i++)
     	 	 {
     	 	 	v = (Vector)data.elementAt(i);
     	 	 	String status = (String)v.elementAt(0);
     	 	 	
     	 	 	if(status.equals("END"))
     	 	 	 break;
     	 	 	
     	 	 	String timeStr = (String)v.elementAt(2);
     	 	 	if(timeStr.equals("") || timeStr==null)
     	 	 	  totalTime+= time;
     	 	 	
     	 	 	else
     	 	 	 {
     	 	 	 	time = (double)track.timings.getValue(timeStr);
     	 	 	 	totalTime+= time;
     	 	 	 	System.out.println("Total time = "+totalTime+"\tTime = "+time);
     	 	 	 }
     	 	 	 
     	 	 }

	 	 	java.text.NumberFormat nf = java.text.NumberFormat.getInstance();
	 	 	nf.setMaximumFractionDigits(4);
     	 	totalTime = totalTime/24.0;
     	 	
     	 	double num = Double.parseDouble(numField.getText());
     	 	double result = totalTime  % num;
     	 	System.out.println("Total time = "+totalTime+"\tResult = "+result);
     	 	
     	 	label.setText(nf.format(result));
     	 } 
     }
	
	private void positionSlider()
	 {
	 	int position = table.getSelectedRow();
	 	double percentage = 0;
	 	double max = 0;
	 	
	 	String str = (String)table.getValueAt(0,2);
	 	double value = track.timings.getValue(str);
	 	
	 	for(int i=1;i<table.getRowCount();i++)
	 	 {
	 	 	str = (String)table.getValueAt(i,2);
	 	 	
	 	 	if(((String)table.getValueAt(i,0)).equals("END"))
	 	 	 break;
	 	 	 
	 	 	if(str.equals("") || str.equals(null))
	 	 	 {
	 	 	 }
	 	 	
	 	 	else
	 	 	 value = track.timings.getValue(str);
	 	 	  
	 	 	
 	 	 	max+= value;
 	 	 	
 	 	 	if(i<=position)
 	 	 	 percentage+= value;
	 	 }
	 	 
	 	percentage = percentage/max * 100;
	 	
	 	System.out.println("position = "+percentage);
    	begin.setValue((int)percentage);
	 	
	 }
	 
	public static void main(String[] args)
	 {
		new MyMidi();
	 }	
 }
