package mymidi.uilayer;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;



public class SaveTable extends JPanel implements MouseListener, ClickEventListener
 {
 	
	public static final int PITCH_TYPE = 100;
	public static final int SPEED_TYPE = 200;
	public static final int CELL_TYPE = 300;
    public static final int ALL_TYPE = 400;
    
	SelectionBox[][] cells;
	SelectionBox[] speeds;
	SelectionBox[] pitches;
	SelectionBox all;
	ClickEventListener listener;
	 
	public SaveTable()
	 {
	 	speeds = new SelectionBox[11];
	 	pitches = new SelectionBox[11];
	 	cells = new SelectionBox[11][11];

	 	int leftMargin = 20;
	 	int topMargin = 50;
	 	int cellSize = 15;
		int gap = 4;
		
	 	all = new SelectionBox(leftMargin+cellSize*11+gap*10+10, topMargin, cellSize, cellSize, 0, ALL_TYPE, true);
	 			
	 	for(int i=0;i<11;i++)
	 	 {
	 	 	pitches[i] = new SelectionBox(leftMargin, topMargin, cellSize, cellSize, i, PITCH_TYPE, true);
	 	 	leftMargin = leftMargin + cellSize + gap;
		 }

		leftMargin = leftMargin+6;
		topMargin = 75;

	 	for(int i=0;i<11;i++)
	 	 {
	 	 	speeds[i] = new SelectionBox(leftMargin, topMargin, cellSize, cellSize, i, SPEED_TYPE, true);
	 	 	topMargin = topMargin + cellSize + gap;
		 }
		
		leftMargin = 20;
		topMargin = 75;
				 	 	
	 	for(int i=0;i<11;i++)
	 	 {
	 	 	leftMargin = 20;
	 	 	for(int j=0;j<11;j++)
	 	 	 {
	 	 	 	cells[i][j] = new SelectionBox(leftMargin, topMargin, cellSize, cellSize, 0, CELL_TYPE, true);
	 	 	 	leftMargin = leftMargin + cellSize + gap;
	 	 	 }
	 	 	
	 	 	topMargin = topMargin + cellSize + gap; 
	 	 }
	 	 
	 	 addMouseListener(this);
	 	 addClickEventListener(this);
	 }	
 	
 	public boolean[][] getSelection()
 	 {
 	 	boolean[][] selection = new boolean[11][11];
 	 	
 	 	for(int i=0;i<11;i++)
 	 	 {
 	 	 	for(int j=0;j<11;j++)
 	 	 	 selection[i][j] = cells[i][j].getSelected();
 	 	 }
 	 	
 	 	return selection; 
 	 }
 	 
    public void paint(Graphics g)
     {
        Graphics2D g2 = (Graphics2D) g;
        Dimension d = getSize();

        g2.setBackground(getBackground());
        g2.clearRect(0, 0, d.width, d.height);

        g2.setColor(Color.white);
        g2.fillRect(0, 0, 310,295);
        
        g2.setColor(Color.MAGENTA);
        g2.drawString("Pitches", 100,20);
        
        g2.setColor(Color.BLUE);
        for(int i=-5;i<=5;i++)
         	g2.drawString(""+i, 25+(i+5)*19, 43);
        
        g2.setColor(Color.MAGENTA);
        g2.drawString("S", 295,121);
        g2.drawString("p", 295,140);
        g2.drawString("e", 295,159);
        g2.drawString("e", 295,178);
        g2.drawString("d", 295,197);
        g2.drawString("s", 295,216);
        
        g2.setColor(Color.BLUE);
        for(int i=-5;i<=5;i++)
         	g2.drawString(""+((i+5)*10+50), 257, 89+(i+5)*19);
         	 
        g2.setColor(Color.BLACK);
        
        if(all.getSelected())
         g2.fill(all);
        
        g2.draw(all);
        
        for(int i=0;i<11;i++)
         {
         	if(speeds[i].getSelected())
         	  g2.fill(speeds[i]);
         	 
         	g2.draw(speeds[i]);
         
         	if(pitches[i].getSelected())
         	  g2.fill(pitches[i]);
         	 
         	g2.draw(pitches[i]);
         	
         	for(int j=0;j<11;j++)
         	 {
         	 	if(cells[i][j].getSelected())
         	 	 	g2.fill(cells[i][j]);
         	 	
         	 	g2.draw(cells[i][j]) ;
         	 }
         }
       }  
        public void mousePressed(MouseEvent e){}
         
        public void mouseReleased(MouseEvent e){}
         
        public void mouseExited(MouseEvent e){}
         
        public void mouseClicked(MouseEvent e)
         {
         	SelectionBox cell = getCell(e);
         	
         	if(cell != null)
         	 {
         	 	System.out.println("found cell");
         	 	boolean selected = cell.getSelected();
         	 	selected = !selected;
         	 	
         	    cell.setSelected(selected);
         	 
	         	if(cell.getType() != CELL_TYPE)
	         	 {
	         	 	ClickEvent ce = new ClickEvent(this, cell.getType(), cell.getIndex(), cell.getSelected());
	         	 	listener.onClick(ce);
	         	 } 
         	} 
         	 repaint();
         }
         
        public void mouseEntered(MouseEvent e) { }
        
        public void addClickEventListener(ClickEventListener listener)
         {
         	this.listener = listener;
         } 
         
		public void onClick(ClickEvent ce)
		 {
		 	int cell_type = ce.getType();
		 	
		 	if(cell_type != CELL_TYPE)
		 	 {
		 	 	boolean select = ce.getSelected();
		 	 	int index = ce.getIndex();
		 	 	
		 	 	if(cell_type == ALL_TYPE)
		 	 	 {
		 	 	 	for(int i=0;i<11;i++)
		 	 	 	 {
		 	 	 	 	speeds[i].setSelected(select);
		 	 	 	 	pitches[i].setSelected(select);
		 	 	 	 	
		 	 	 	 	for(int j=0;j<11;j++)
		 	 	 	 	 	cells[i][j].setSelected(select);
		 	 	 	 }
		 	 	 }
		 	 	
		 	 	if(cell_type == PITCH_TYPE)
		 	 	 {
		 	 	 	for(int i=0;i<11;i++)
		 	 	 	 cells[i][index].setSelected(select);
		 	 	 }
		 	 	
		 	 	if(cell_type == SPEED_TYPE)
		 	 	 {
		 	 	 	for(int i=0;i<11;i++)
		 	 	 	 cells[index][i].setSelected(select);
		 	 	 }
		 	 	
		 	 	cells[5][5].setSelected(true);   
		 	 }
		 }
		 
		private SelectionBox getCell(MouseEvent me)
		  {
		  	if(all.contains(me.getPoint()))
		  	 return all;
		  	 
		  	for(int i=0;i<11;i++)
		  	 {
		  	 	if(speeds[i].contains(me.getPoint()))
		  	 	 return speeds[i];
		  	 	
		  	 	if(pitches[i].contains(me.getPoint()))
		  	 	 return pitches[i];
		  	 	  
		  	 	for(int j=0;j<11;j++)
		  	 	 {
		  	 	 	if(cells[i][j].contains(me.getPoint()))
		  	 	 		return cells[i][j];
		  	 	 }
		  	 }
		  	
		  	return null; 
		  }
		  
	class SelectionBox extends Rectangle
 	{
 		boolean selected;
 		int type;
 		int index;
 		
 		public SelectionBox(int x, int y, int width, int height, int index, int type, boolean selected)
 		 {
 		 	super(x, y, width, height);
 		 	this.index = index;
 		 	this.type = type;
 		 	this.selected = selected;
 		 }
 		
 		public void setSelected(boolean bool)
 		 {
 		 	this.selected = bool;
 		 }
 		
 		public boolean getSelected()  
 		 {
 		 	return selected;
 		 }
 		 
 		public int getType() 
 		 {
 		 	return type;
 		 }
 		 
 		public int getIndex()
 		 {
 		 	return index;
 		 }
 	}
 
}