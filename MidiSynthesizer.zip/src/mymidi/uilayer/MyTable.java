package mymidi.uilayer;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.event.*;
import java.util.Vector;

public class MyTable extends JTable 
 {
 	
	public MyTable()
	 {
	 	super();
	 }
	 
	 public void setColumns(int size, Vector columns)
	 {
	 	Vector data = new Vector();
    	
    	for(int i=0;i<size;i++)
    	{
    		Vector v = new Vector();
    		for(int j=0;j<columns.size();j++)
    			v.addElement("");
    		data.addElement(v);
    	}
	 	
	 	TableModel model = new DefaultTableModel(data, columns);
	 	super.setModel(model);
	 }

	public Vector getDataVector()
	 {
	 	Vector dataVector = new Vector();
	 	DefaultTableModel tableModel = (DefaultTableModel)super.getModel();
	 	
	 	int rows = tableModel.getRowCount();
 	 	int cols = tableModel.getColumnCount();
	 	 	
 	 	for(int i=0;i<rows;i++)
 	 	 {
 	 	 	Vector v = new Vector();
 	 	 	
 	 	 	for(int j=0;j<cols;j++)
 	 	 	 {
 	 	 	 	Object val = tableModel.getValueAt(i,j);
 	 	 		v.addElement(val); 	
 	 	 	 }
 	 	 	 
 	 	 	dataVector.addElement(v); 
 	 	 }
	 	 
	 	return dataVector; 
	 }

	public void setDataVector(Vector data) 
	 {
	 	int rows = data.size();
	 	int rowSize = super.getRowCount();
	 	int colSize = super.getColumnCount();
	 	
	 	DefaultTableModel model = (DefaultTableModel)super.getModel();
	 	
	 	if(rowSize<rows)
	 	{
	 		int difference = rows - rowSize + 100;
	 		for(int i=0;i<difference;i++)
	 		 {
	 		 	Vector v = new Vector();
	 		 	for(int j=0;j<colSize;j++)
	 		 	    v.addElement("");
	 		 	
	 		 	model.insertRow(i+rowSize, v);
	 		 }
	 	}
	 	
	 	for(int i=0;i<rows;i++)
	 	{
	 		Vector v = (Vector)data.elementAt(i);
	 		int columns = v.size();
	 		
	 		for(int j=0;j<columns;j++)
	 		{
	 			String str = (String)v.elementAt(j);
	 			super.setValueAt(str, i, j);
	 		}
	 	}
	 }
 }
