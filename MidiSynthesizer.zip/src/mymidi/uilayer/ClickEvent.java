package mymidi.uilayer;

import java.util.EventObject;

public class ClickEvent extends EventObject
 {
	int type;
	int index;
	boolean select;
	
	public ClickEvent(Object source, int type, int index, boolean select)
	 {
		super(source);
		this.type = type;
		this.index = index;
		this.select = select;
	 }
	 
	public int getType() 	
	 {
	 	return type;
	 }
	
	public int getIndex()
	 {
	 	return index;
	 }
	
	public boolean getSelected()
	 {
	 	return select;
	 }  
 }
