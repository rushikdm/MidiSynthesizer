package mymidi.uilayer;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.sound.midi.*;
import java.util.Vector;

import mymidi.midilayer.MidiData;

public class MidiSynth extends JPanel
 {

    final int ON = 0, OFF = 1;
    final Color jfcBlue = new Color(204, 204, 255);
    final Color pink = new Color(255, 175, 175);
    Synthesizer synthesizer;
    MidiChannel cc;
    Vector keys = new Vector();
    Vector whiteKeys = new Vector();
    Piano piano;
	NoteEventListener noteEventListener;
    MidiData midiData = new MidiData();
    JButton[] timingButtons;
    String time = "1";
    JCheckBox record;
    
    public MidiSynth() {
        setLayout(new BorderLayout());

        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        EmptyBorder eb = new EmptyBorder(5,5,5,5);
        BevelBorder bb = new BevelBorder(BevelBorder.LOWERED);
        CompoundBorder cb = new CompoundBorder(eb,bb);
        p.setBorder(new CompoundBorder(cb,eb));
        JPanel pp = new JPanel(new BorderLayout());
        pp.setBorder(new EmptyBorder(10,10,10,5));
        pp.add(piano = new Piano());
        
        String[] timings = midiData.timings.getStrArray();
        
        Box timeBox = Box.createHorizontalBox();
        
        timingButtons = new JButton[timings.length];
        
        for(int i=0;i<timings.length;i++)
         {
         	timingButtons[i] = new JButton(timings[i]);
         	timingButtons[i].addActionListener(new ActionListener()
         	 {
	         	public void actionPerformed(ActionEvent event)
	         	 {
	         	 	JButton button = (JButton)event.getSource();
	         	 	setSelected(button);
	         	 }
         	 	
         	 });
         	 
         	 timeBox.add(timingButtons[i]);
         	 timeBox.add(Box.createHorizontalStrut(3));
         }

        setSelected(timingButtons[2]);
        record = new JCheckBox("Record");
        timeBox.add(Box.createHorizontalStrut(10));
        timeBox.add(record);
        
        p.add(timeBox);        
        p.add(pp);

        add(p);
        open();
    }

    public void open() {
    	
    	Instrument instruments[];
    	
        try {
            if (synthesizer == null) {
                if ((synthesizer = MidiSystem.getSynthesizer()) == null) {
                    System.out.println("getSynthesizer() failed!");
                    return;
                }
            } 
            synthesizer.open();
        } catch (Exception ex) { ex.printStackTrace(); return; }

        Soundbank sb = synthesizer.getDefaultSoundbank();
	if (sb != null) {
            instruments = synthesizer.getDefaultSoundbank().getInstruments();
            synthesizer.loadInstrument(instruments[0]);
        }
        MidiChannel midiChannels[] = synthesizer.getChannels();
        
        cc = midiChannels[0];
        cc.programChange(70);

    }


    public void close() {
        if (synthesizer != null) {
            synthesizer.close();
        }
        synthesizer = null;
    }


    /**
     * Black and white keys or notes on the piano.
     */
    class Key extends Rectangle {
        int noteState = OFF;
        int kNum;
        public Key(int x, int y, int width, int height, int num) {
            super(x, y, width, height);
            kNum = num;
        }
        public boolean isNoteOn() {
            return noteState == ON;
        }
        public void on() {
            setNoteState(ON);
            cc.noteOn(kNum, 64);
        }
        public void off() {
            setNoteState(OFF);
            cc.noteOff(kNum, 64);
            }
        public int getKeyNum()
         {
         	return kNum;
         }
         
        public void setNoteState(int state) {
            noteState = state;
        }
    } // End class Key



    /**
     * Piano renders black & white keys and plays the notes for a MIDI 
     * channel.  
     */
    class Piano extends JPanel implements MouseListener {

        Vector blackKeys = new Vector();
        Key prevKey;
        final int kw = 16, kh = 80;


        public Piano() {
            setLayout(new BorderLayout());
            setPreferredSize(new Dimension(42*kw, kh+1));
            int transpose = 24;  
            int whiteIDs[] = { 0, 2, 4, 5, 7, 9, 11 }; 
          
            for (int i = 0, x = 0; i < 6; i++) {
                for (int j = 0; j < 7; j++, x += kw) {
                    int keyNum = i * 12 + whiteIDs[j] + transpose;
                    whiteKeys.add(new Key(x, 0, kw, kh, keyNum));
                }
            }
            for (int i = 0, x = 0; i < 6; i++, x += kw) {
                int keyNum = i * 12 + transpose;
                blackKeys.add(new Key((x += kw)-4, 0, kw/2, kh/2, keyNum+1));
                blackKeys.add(new Key((x += kw)-4, 0, kw/2, kh/2, keyNum+3));
                x += kw;
                blackKeys.add(new Key((x += kw)-4, 0, kw/2, kh/2, keyNum+6));
                blackKeys.add(new Key((x += kw)-4, 0, kw/2, kh/2, keyNum+8));
                blackKeys.add(new Key((x += kw)-4, 0, kw/2, kh/2, keyNum+10));
            }
            keys.addAll(blackKeys);
            keys.addAll(whiteKeys);
            addMouseListener(this);
		}
     
        public void mousePressed(MouseEvent e) { 
            prevKey = getKey(e.getPoint());
            if (prevKey != null) {
                prevKey.on();
                repaint();
            }
        }
        public void mouseReleased(MouseEvent e) { 
            if (prevKey != null) {
                prevKey.off();
                repaint();
                if(record.isSelected())
                 {
                 	NoteEvent nEvent = new NoteEvent(this, midiData.notes.getString(prevKey.getKeyNum()), time);
                    noteEventListener.onNoteEvent(nEvent);
                 }
                
            }
        }
        public void mouseExited(MouseEvent e) { 
            if (prevKey != null) {
                prevKey.off();
                repaint();
                prevKey = null;
            }
        }
        public void mouseClicked(MouseEvent e) { }
        public void mouseEntered(MouseEvent e) { }


        public Key getKey(Point point) {
            for (int i = 0; i < keys.size(); i++) {
                if (((Key) keys.get(i)).contains(point)) {
                    return (Key) keys.get(i);
                }
            }
            return null;
        }

        public void paint(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            Dimension d = getSize();

            g2.setBackground(getBackground());
            g2.clearRect(0, 0, d.width, d.height);

            g2.setColor(Color.white);
            g2.fillRect(0, 0, 42*kw, kh);

            for (int i = 0; i < whiteKeys.size(); i++) {
                Key key = (Key) whiteKeys.get(i);
                if (key.isNoteOn()) {
                    g2.setColor(pink);
                    g2.fill(key);
                }
                g2.setColor(Color.black);
                g2.draw(key);
            }
            for (int i = 0; i < blackKeys.size(); i++) {
                Key key = (Key) blackKeys.get(i);
                if (key.isNoteOn()) {
                    g2.setColor(pink);
                    g2.fill(key);
                    g2.setColor(Color.black);
                    g2.draw(key);
                } else {
                    g2.setColor(Color.black);
                    g2.fill(key);
                }
            }
        }
    } // End class Piano

	public void addNoteEventListener(NoteEventListener NEList)
	 {
	 	this.noteEventListener = NEList;
	 }
	
	private void setSelected(JButton button)
	 {
	 	button.setBackground(Color.WHITE);
	 	button.setForeground(Color.BLACK);
	 	
	 	for(int i=0;i<timingButtons.length;i++)
	 	 {
	 	 	if(button != timingButtons[i])
	 	 	 {
	 	 	 	timingButtons[i].setBackground(Color.BLACK);
	 	 	 	timingButtons[i].setForeground(Color.WHITE);
	 	 	 }
	 	 }
	 	 
	 	time = button.getText(); 
	 } 
	 
    public static void main(String args[]) {
        final MidiSynth midiSynth = new MidiSynth();
        midiSynth.open();
        JFrame f = new JFrame("Midi Synthesizer");
        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {System.exit(0);}
        });
        f.getContentPane().add("Center", midiSynth);
        f.pack();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int w = 760;
        int h = 470;
        f.setLocation(screenSize.width/2 - w/2, screenSize.height/2 - h/2);
        f.setSize(w, h);
        f.setVisible(true);
    }
 } 
