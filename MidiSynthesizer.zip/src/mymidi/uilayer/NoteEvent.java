package mymidi.uilayer;

import java.util.EventObject;

public class NoteEvent extends EventObject
 {
	private String noteString;
	private String timing;
	
	public NoteEvent(Object source, String note, String time)
	 {
	 	super(source);
		this.noteString = note;
		this.timing = time;
	 }	
	 
	public String getNote()
	 {
	 	return noteString;
	 }
	
	public String getTiming()
	 {
	 	return timing;
	 } 
 }
