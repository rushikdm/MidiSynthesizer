package mymidi.uilayer;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.PopupMenuListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.border.BevelBorder;
import java.awt.event.*;
import java.util.Vector;
import java.awt.Color;

import mymidi.midilayer.MidiData;

public class MusicTable extends MyTable implements MouseListener,PopupMenuListener
 {
	private JMenuItem insert,delete,cut,copy,paste;
 	private JPopupMenu popup;
 	private Vector columns;
 	private static Vector bufferData;
	MidiData midiData;
	
	public MusicTable(int size)
    {
    	super();
        bufferData = new Vector();
    	columns = new Vector();
    	columns.addElement("Instrument");
    	columns.addElement("Note");
    	columns.addElement("Timing");
    	columns.addElement("Volume");
    	
    	super.setColumns(size, columns);
    	
    	initializePopups();
        setTableRenderer();
    }
    
    private void initializePopups()
     {
        this.popup = new JPopupMenu();
		popup.setLightWeightPopupEnabled(true);
	 	popup.setBorder(new BevelBorder(BevelBorder.RAISED));
 		popup.addPopupMenuListener(this);
 		
 		super.addMouseListener(this); 	
		super.setAutoResizeMode(AUTO_RESIZE_OFF);
		super.setCellSelectionEnabled(true);

		cut = new JMenuItem("Cut");
		cut.addActionListener(new ActionListener()
		 {
		 	public void actionPerformed(ActionEvent event)
		 	 {
		 	 	tableListeners(event);
		 	 }
		 });
		 
		addPopupMenu(cut);
		
		copy = new JMenuItem("Copy");
		copy.addActionListener(new ActionListener()
		 {
		 	public void actionPerformed(ActionEvent event)
		 	 {
		 	 	tableListeners(event);
		 	 }
		 });
		 
		addPopupMenu(copy);

		paste = new JMenuItem("Paste");
		paste.addActionListener(new ActionListener()
		 {
		 	public void actionPerformed(ActionEvent event)
		 	 {
		 	 	tableListeners(event);
		 	 }
		 });
		 
		addPopupMenu(paste);

		insert = new JMenuItem("Insert");
		insert.addActionListener(new ActionListener()
		 {
		 	public void actionPerformed(ActionEvent event)
		 	 {
		 	 	tableListeners(event);
		 	 }
		 });
		 
		addPopupMenu(insert);
		
		delete = new JMenuItem("Delete");
		delete.addActionListener(new ActionListener()
		 {
		 	public void actionPerformed(ActionEvent event)
		 	 {
		 	 	tableListeners(event);
		 	 }
		 });
		 
		addPopupMenu(delete);
		
    }	
 
    private void setTableRenderer()
     {
     	midiData= new MidiData();
     	setColumn((String)columns.elementAt(0), midiData.instruments.getStrArray(), new Color(225,225,230));
     	setColumn((String)columns.elementAt(1), midiData.notes.getStrArray(),  new Color(255,225,230));
     	setColumn((String)columns.elementAt(2), midiData.timings.getStrArray(), new Color(225,225,230));
     	setColumn((String)columns.elementAt(3), midiData.volumes.getStrArray(),  new Color(255,225,230));
     }
	
	private void setColumn(String name, String[] array, Color color)
	 {
 		JComboBox comboBox = new JComboBox(array);
		
		TableColumn column = getColumn(name);
		column.setCellEditor(new DefaultCellEditor(comboBox));
        
        DefaultTableCellRenderer columnRenderer = new DefaultTableCellRenderer();
        columnRenderer.setBackground(color);
        columnRenderer.setToolTipText("Click for Combo Box");
        column.setCellRenderer(columnRenderer);		
	 }
  
	public void addPopupMenu(JMenuItem item)
	 {
	 	popup.add(item);
	 }

	public void mousePressed(MouseEvent event)
 	 {
 	 	checkPopup(event);
 	 }
 	
 	public void mouseClicked(MouseEvent event)
 	 {
 	 	checkPopup(event);
 	 } 
 	 
 	public void mouseEntered(MouseEvent event)
 	 {
 	 	
 	 }
 	
 	public void mouseExited(MouseEvent event)
 	 {
 	 	
 	 }
 	
 	public void mouseReleased(MouseEvent event)
 	 {
 	 	checkPopup(event);
 	 }
 	
 	private void checkPopup(MouseEvent event)
 	 {
 	 	if(event.isPopupTrigger())
 	 	 	popup.show(this,event.getX(),event.getY());
 	 }
 	
 	public void popupMenuWillBecomeVisible(PopupMenuEvent e) 
 	 {
 	
 	 }
 	
 	public void popupMenuWillBecomeInvisible(PopupMenuEvent e) 
 	 {

 	 }

	public void popupMenuCanceled(PopupMenuEvent e) 
 	 {
 	 	popup.setVisible(false);
 	 }   	 
 
	private void tableListeners(ActionEvent event)
	 {
	 	if(event.getSource()==cut)
	 	 {
	 	 	int row = getSelectedRow();
	 	 	int col = getSelectedColumn();
	 	 	
	 	 	int nRows = getSelectedRowCount();
	 	 	int nCols = getSelectedColumnCount();
	 	 	bufferData.clear();
	 	 	
	 	 	for(int i=row;i<row+nRows;i++)
	 	 	 {
	 	 	 	Vector v = new Vector();
	 	 	 	
	 	 	 	for(int j=col;j<col+nCols;j++)
	 	 	 	 {
	 	 	 	 	v.addElement((String)getValueAt(i,j));
	 	 	 	 	setValueAt("",i,j);
	 	 	 	 }
	 	 	 	  
	 	 	 	bufferData.addElement(v);
	 	 	 }	 	 	
	 	 }
	 	 
	 	if(event.getSource()==copy)
	 	 {
	 	 	int row = getSelectedRow();
	 	 	int nRows = getSelectedRowCount();
	 	 	int col = getSelectedColumn();
	 	 	int nCols = getSelectedColumnCount();
	 	 	
	 	 	bufferData.clear();
	 	 	
	 	 	for(int i=row;i<row+nRows;i++)
	 	 	 {
	 	 	 	Vector v = new Vector();
	 	 	 	
	 	 	 	for(int j=col;j<col+nCols;j++)
	 	 	 	 	v.addElement((String)getValueAt(i,j));
	 	 	 	  
	 	 	 	bufferData.addElement(v);
	 	 	 }	 	 	
	 	 }
		
	 	if(event.getSource()==paste)
	 	 {
	 	 	int row = super.getSelectedRow();
	 	 	int col = super.getSelectedColumn();
			int n = bufferData.size();
			int rowSize = getRowCount();
	 	    int colSize = columns.size();
	 	
	 		DefaultTableModel model = (DefaultTableModel)getModel();
	 	
	 		if(rowSize<row+n)
	 	    {
		 		int difference = row + n - rowSize + 100;
		 		for(int i=0;i<difference;i++)
		 		 {
		 		 	Vector v = new Vector();
		 		 	for(int j=0;j<colSize;j++)
		 		 	    v.addElement("");
		 		 	
		 		 	model.insertRow(i+rowSize, v);
		 		 }
		 	}
 				 	 	
	 	 	for(int i=row;i<row+n;i++)
	 	 	 {
	 	 	 	Vector v = (Vector)bufferData.elementAt(i-row);
	 	 	 	for(int j=col;j<col+v.size();j++)
	 	 	 	 {
	 	 	 	 	//if(i<super.getColumnCount() && j<super.getRowCount())
	 	 	 	 	 setValueAt((String)v.elementAt(j-col),i,j);
	 	 	 	 }	
	 	 	 	 	
	 	 	 }	 	 	
	 	 }
		
	 	if(event.getSource()==insert)
	 	 {
	 	 	int row = getSelectedRow();
	 	 	int n = getSelectedRowCount();
	 	 	int cols = getColumnCount();
	 	 	DefaultTableModel tableModel = (DefaultTableModel)getModel();
	 	 	
	 	 	for(int i=row;i<row+n;i++)
	 	 	 {
	 	 	 	Vector v = new Vector();
	 	 	 	
	 	 	 	for(int j=0;j<cols;j++)
	 	 	 	 v.addElement("");
	 	 	 	  
	 	 	 	((DefaultTableModel)tableModel).insertRow(i,v);
	 	 	 }
	 	 }
	 	 
	 	if(event.getSource()==delete)
	 	 {
	 	 	int option = JOptionPane.showConfirmDialog(this,"Do you want to delete selected rows","Confirm delete",JOptionPane.YES_NO_OPTION);
			DefaultTableModel tableModel = (DefaultTableModel)getModel();
			
	 	 	if(option==JOptionPane.YES_OPTION)
	 	 	{
		 	 	int row = getSelectedRow();
		 	 	int n = getSelectedRowCount();
		 	 	int cols = getColumnCount();
		 	 	
		 	 	for(int i=row+n-1;i>=row;i--)
		 	 	 ((DefaultTableModel)tableModel).removeRow(i);
		 	 	 
		 	 	int rows = getRowCount();
		 	 	
		 	 	if(rows==0)
		 	 	 {
		 	 	 	Vector data = new Vector();
		 	 	 	
		 	 	 	for(int i=0;i<100;i++)
		 	 	 	 {
		 	 	 	 	Vector v = new Vector();
		 	 	 	 	
		 	 	 	 	for(int j=0;j<cols;j++)
		 	 	 	 	  v.addElement("");
		 	 	 	 	data.addElement(v);
		 	 	 	 }
		 	 	 	
		 	 	    setDataVector(data); 
		 	 	 	setTableRenderer(); 
		 	 	 } 
			}	 	 	
	 	 } 
	 } 

}
