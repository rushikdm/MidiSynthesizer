package mymidi.uilayer;

import java.util.EventListener;

public interface NoteEventListener extends EventListener 
 {
 	public void onNoteEvent(NoteEvent noteEvent);
 }
