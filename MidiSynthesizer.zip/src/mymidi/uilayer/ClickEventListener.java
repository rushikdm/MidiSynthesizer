package mymidi.uilayer;

import java.util.EventListener;

public interface ClickEventListener extends EventListener
 {
 	public void onClick(ClickEvent event);
 }
