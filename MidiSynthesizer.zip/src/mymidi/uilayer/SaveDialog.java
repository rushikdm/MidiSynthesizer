package mymidi.uilayer;

import javax.swing.*;
import mymidi.midilayer.MidiSong;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

import mymidi.midilayer.MyTrack;

public class SaveDialog extends JDialog
 {
	JTextField dirText;
	JButton dirButton;
	JButton save;
	JButton cancel;
	MidiSong song;
	SaveTable stable;
	File file;
	
	public SaveDialog(Frame owner, MidiSong song)
	 {
		super(owner, "Save Midi Files  option dialog", true);
		Container container = getContentPane();
		this.song = song;
			
		initialize();
		
		Box dirBox1 = Box.createVerticalBox();
		dirBox1.add(Box.createVerticalStrut(15));
		
		Box dirBox = Box.createHorizontalBox();
		dirBox.add(Box.createHorizontalStrut(10));
		dirBox.add(new JLabel("Select Directory: "));
		dirBox.add(Box.createHorizontalStrut(10));
		dirBox.add(dirText);
		dirBox.add(Box.createHorizontalStrut(10));
		dirBox.add(dirButton);
		dirBox.add(Box.createHorizontalStrut(10));
		
		dirBox1.add(dirBox);
		
		JPanel savePanel = new JPanel();
		savePanel.add(save);
		savePanel.add(cancel);
		
		Box entire = Box.createVerticalBox();
		entire.add(Box.createVerticalStrut(20));
		
		Box total = Box.createHorizontalBox();
		total.add(Box.createHorizontalStrut(160));
		total.add(stable);
		total.add(Box.createHorizontalStrut(30));
		
		entire.add(total);
		entire.add(Box.createVerticalStrut(30));
		
		container.add("North",dirBox1);
		container.add("Center",entire);
		container.add("South",savePanel);
		setBounds(50,50,550,470);
		setResizable( false );
		setVisible(true);
	}	
	
	private void initialize()
	 {
	 	dirText = new JTextField(10);
	 	dirText.setText("H:"+File.separator+"MidiSongs"+File.separator);
	 	dirText.setEditable(false);
	 	
	 	
	 	dirButton = new JButton("...");
	 	addALFor(dirButton);
	 	
	 	save = new JButton("Save");
	 	addALFor(save);
	 	
	 	cancel = new JButton("Cancel");
	 	addALFor(cancel);
	 	
	 	stable = new SaveTable();
	 	
	 } 
	 
	private void addALFor(JButton button)
	 {
	 	button.addActionListener(new ActionListener()
	 	 {
	 	 	public void actionPerformed(ActionEvent event)
	 	 	 {
	 	 	 	actionListeners(event);
	 	 	 }
	 	 });
	 }
	 
	private void actionListeners(ActionEvent event)
	 {
	 	if(event.getSource() == dirButton)
	 	 {

            File file = new File("H:"+File.separator+"MidiSongs"+File.separator);
            JFileChooser fc = new JFileChooser(file);
            fc.setFileFilter(new javax.swing.filechooser.FileFilter() {
                public boolean accept(File f) {
                    if (f.isDirectory()) {
                        return true;
                    }
                    return false;
                }
                public String getDescription() {
                    return "Save as .mid file.";
                }
            });
            if (fc.showSaveDialog(null) == JFileChooser.APPROVE_OPTION)
             {
             	file = fc.getSelectedFile();
				dirText.setText(fc.getSelectedFile().getAbsolutePath());
	 	     }
	 	 }
	 	if(event.getSource() ==  save)
	 	 {
	 	 	MyTrack track = new MyTrack();
	 	 	file = new File(dirText.getText());
	 	 	String str = file.getAbsolutePath();
	 	 	
	 	 	String selectedPath = str.substring(0,str.length()-4);
	 	 	
	 	 	String name = file.getName();
	 	 	String fileName = name.substring(0,name.length()-4);
	 	 	
	 	 	File parentDir = new File(selectedPath);
	 	 	parentDir.mkdir();
	 	 	
	 	 	song.setPitch(0);
	 	 	song.setSpeed(100);
	 	 	File f1 = new File(parentDir.getAbsolutePath() + File.separator + fileName + ".mid");
			
			track.save(f1, song);
			
	 	 	int[] pitches = {-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5};
	 	 	int[] speeds = {50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150};
	 	 	
	 	 	boolean[][] selection = stable.getSelection();

	 	 	for(int i=0;i<11;i++)
	 	 	 {
	 	 	 	boolean create = false;
	 	 	 	
	 	 	 	for(int j=0;j<11;j++)
	 	 	 	 {
	 	 	 	 	if(selection[j][i])
	 	 	 	 	 {
	 	 	 	 	 	create = true;
	 	 	 	 	 	break;
	 	 	 	 	 }
	 	 	 	 }
	 	 	 	 
	 	 	 	if(create) 
	 	 	 	 {
	 	 	 	 	 String subDirStr = parentDir.getAbsolutePath() + File.separator + fileName + "_Pitch_"+pitches[i];
	 	 	 		 File subdir = new File(subDirStr);
	 	 	 		 subdir.mkdir();
	 	 	 		 song.setPitch(pitches[i]);
	 	 	 		 
	 	 	 		 for(int j=0;j<11;j++)
	 	 	 		  {
	 	 	 		  	if(selection[j][i])
	 	 	 		  	 {
	 	 	 		  	 	song.setSpeed(speeds[j]);
	 	 	 		  	 	File ff = new File(subdir.getAbsolutePath() + File.separator + fileName + "_P_"+pitches[i]+"_S_"+speeds[j]+".mid");
	 	 	 		  	 	track.save(ff, song);
	 	 	 		  	 }
	 	 	 		  }
	 	 	 		 
	 	 	 	 }
	 	 	 	
	 	 	 }
	 	 	
	 	 }
	 	 
	 	if(event.getSource() == cancel)
	 	 {
	 	 	
	 	 } 
	 }  
 }
