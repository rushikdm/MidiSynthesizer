package mymidi.uilayer;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.border.BevelBorder;
import java.awt.event.*;
import java.awt.*;
import java.util.Vector;
import javax.swing.border.*;

import mymidi.midilayer.*;

public class MyMidi extends JFrame implements NoteEventListener
 {
 	MusicTable table;
	JButton play;
	JButton open;
	JButton save;
	JButton calculate;
	MyTrack track;
	JSlider slider;
	JSlider speed;
	JSlider begin;
	JLabel label;
	JTextField numField;
	private JMenuItem goAt;
	MidiData midiData;
	MidiSong song;
	JButton[] trackButtons;
	JCheckBox[] trackChecks;
	int currentTrack=0;
    MidiSynth synth;
   	boolean isPlaying = false;
   	
	public MyMidi()
	 {
	 	super("Midi Synthesizer and Composer");
 		Container container = getContentPane();
 		
	 	initialise();

		Box left = Box.createVerticalBox(); 
		left.add(Box.createVerticalStrut(5)); 
		
		JScrollPane tablepane = new JScrollPane(table);
		left.add(tablepane);
		left.setPreferredSize(new Dimension(300,320));
		
		Box right = Box.createVerticalBox();
		right.add(Box.createVerticalStrut(5));
		right.add(slider);

		right.add(Box.createVerticalStrut(5));
		right.add(speed);

		right.add(Box.createVerticalStrut(5));
		right.add(begin);
		right.add(Box.createVerticalStrut(5));

		Box vbox = Box.createHorizontalBox();
		vbox.add(Box.createHorizontalStrut(10));
		vbox.add(play);
		vbox.add(Box.createHorizontalStrut(10));
		vbox.add(save);
		vbox.add(Box.createHorizontalStrut(10));
		vbox.add(open);
		vbox.add(Box.createHorizontalStrut(10));
		
		right.add(vbox);

		JPanel panel = new JPanel();
 	 	panel.setBorder(new TitledBorder(new EtchedBorder(),"Timing"));
		
		Box hbox = Box.createHorizontalBox();
		hbox.add(new JLabel("Enter No: "));
		hbox.add(Box.createHorizontalStrut(5));
		hbox.add(numField);
		
		vbox = Box.createVerticalBox();
		vbox.add(hbox);
		vbox.add(Box.createVerticalStrut(15));
		vbox.add(label);
		vbox.add(Box.createVerticalStrut(15));
		vbox.add(calculate);
		
 	 	panel.add(vbox,BorderLayout.CENTER);
		right.add(panel);
		right.add(Box.createVerticalStrut(5));
		
		panel = new JPanel();
 	 	panel.setBorder(new TitledBorder(new EtchedBorder(),"Tracks"));
 	 	
		Box trackBox = Box.createVerticalBox();
		
		for(int i=0;i<5;i++)
		 {
			 Box b = Box.createHorizontalBox();
			 b.add(trackChecks[i]);
			 b.add(Box.createHorizontalStrut(3));
			 b.add(trackButtons[i]);
			 trackBox.add(b);
			 trackBox.add(Box.createVerticalStrut(8));
		 }

		panel.add(trackBox);
		
		Box total = Box.createHorizontalBox();
		total.add(Box.createHorizontalStrut(20));
		total.add(left);
		total.add(Box.createHorizontalStrut(20));
		total.add(panel);
		total.add(Box.createHorizontalStrut(20));
		total.add(right);
		total.add(Box.createHorizontalStrut(20));
		
		Box entire = Box.createVerticalBox();
		entire.add(total);
		entire.add(Box.createVerticalStrut(5));
		entire.add(synth);
		JScrollPane spane = new JScrollPane(entire);
		
		container.add(spane);
		pack();
		setVisible(true);
		table.changeSelection(0, 0, false, false);
	 }
	 
    private void initialise()
	 {
	 	midiData = new MidiData();
	 	song = new MidiSong(5);
	 	
	 	synth = new MidiSynth();
	    synth.addNoteEventListener(this);
	    
	 	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 	setBounds(20,20,500,400);
	 	
	 	track = new MyTrack();
		
		table = new MusicTable(500);
	
		play = new JButton(new ImageIcon("images/play.gif"));
		play.setMargin(new Insets(0,0,0,0));
		play.setToolTipText("Play");
		addALFor(play);
		
		 
		save = new JButton(new ImageIcon("images/save.gif"));
		save.setMargin(new Insets(0,0,0,0));
		save.setToolTipText("Save");
		addALFor(save);
		
		open = new JButton(new ImageIcon("images/open.gif"));
		save.setMargin(new Insets(0,0,0,0));
		open.setToolTipText("Open");
		addALFor(open);

		calculate = new JButton("Calculate");
		addALFor(calculate);

		slider = new JSlider(-5,5,0);
		slider.setMinorTickSpacing(1);
		slider.setSnapToTicks(true);
		slider.setPaintLabels(true);
		slider.setPaintTicks(true);

        TitledBorder tb = new TitledBorder(new EtchedBorder());
        tb.setTitle("Pitch = 0");
        slider.setBorder(tb);

		speed = new JSlider(50,150,100);
		speed.setMinorTickSpacing(10);
		speed.setSnapToTicks(true);
		speed.setPaintLabels(true);
		speed.setPaintTicks(true);

        TitledBorder tb1 = new TitledBorder(new EtchedBorder());
        tb1.setTitle("Speed = 100");
        speed.setBorder(tb1);
		
		trackButtons = new JButton[5];
		
		for(int i=0;i<5;i++)
		{
			trackButtons[i] = new JButton(""+i);
			addALFor(trackButtons[i]);
		}
		
		trackChecks = new JCheckBox[5];
		for(int i=0;i<5;i++)
			trackChecks[i] = new JCheckBox();
		
		slider.addChangeListener(new ChangeListener()
		{
			public void stateChanged(ChangeEvent e)
			 {
			 	sliderListener(e);
			 }
		});

		speed.addChangeListener(new ChangeListener()
		{
			public void stateChanged(ChangeEvent e)
			 {
			 	sliderListener(e);
			 }
		});
		
		begin = new JSlider(0,100,0);
		begin.setMinorTickSpacing(1);
		begin.setSnapToTicks(true);
		begin.setPaintLabels(true);
		begin.setPaintTicks(true);

        TitledBorder tb2 = new TitledBorder(new EtchedBorder());
        tb2.setTitle("Start = 0");
        begin.setBorder(tb2);

		begin.addChangeListener(new ChangeListener()
		{
			public void stateChanged(ChangeEvent e)
			 {
			 	sliderListener(e);
			 }
		});
	
	   numField = new JTextField(4);
	   label = new JLabel("  ");
	   
	   goAt = new JMenuItem("Go to");
	   
	   goAt.addActionListener(new ActionListener()
	    {
	    	public void actionPerformed(ActionEvent e)
	    	 {
	    	 	positionSlider();
	    	 }
	    });
	    
	   table.addPopupMenu(goAt);
	}
	
	private void sliderListener(ChangeEvent event)
	 {
        JSlider slid = (JSlider) event.getSource();
        int value = slid.getValue();
        TitledBorder tb = (TitledBorder) slid.getBorder();
        String s = tb.getTitle();
        tb.setTitle(s.substring(0, s.indexOf('=')+1) + " " + s.valueOf(value));
        slid.repaint();
	 }
	 
	private void addALFor(JButton button)
	 {
		button.addActionListener(new ActionListener()
		 {
		 	public void actionPerformed(ActionEvent event)
		 	 {
		 	 	actionListeners(event);
		 	 }
		 });
	 }	

    private void actionListeners(ActionEvent event)
     {
     	for(int i=0;i<5;i++)
     	 {
     	 	if(event.getSource()==trackButtons[i])
     	 	 {
     	 	 	if(i != currentTrack)
     	 	 	 {
     	 	 	     Vector v = table.getDataVector();
     	 	 	     song.setTrack(currentTrack, v);
     	 	 	     table.setDataVector(song.getTrack(i));
     	 	 	 	 currentTrack = i;
     	 	 	 	 
     	 	 	 	 trackButtons[i].setBackground(Color.WHITE);
     	 	 	 	 trackButtons[i].setForeground(Color.BLACK);
     	 	 	 	 
     	 	 	 	 for(int j=0;j<5;j++)
     	 	 	 	  {
     	 	 	 	  	if(i==j)
     	 	 	 	  	 continue;
     	 	 	 	  	trackButtons[j].setBackground(Color.GRAY);
     	 	 	 	    trackButtons[j].setForeground(Color.WHITE);
     	 	 	 	  }
     	 	 	 }
     	 	 }
     	 }
     	 
     	if(event.getSource()==play)
     	 {
     	 	
		 	if(!isPlaying)
		 	 {
				for(int i=0;i<5;i++)
				 	song.setSelected(i, trackChecks[i].isSelected());
				 
	     	 	if(song.getNumTracksSelected() == 0)
	     	 	    JOptionPane.showMessageDialog(null,"Please select atleast single Track for playing.","No Track error",JOptionPane.ERROR_MESSAGE);
	     	 	else
	     	 	 {
	     	 	 	  play.setIcon(new ImageIcon("images/stop.gif"));
	     	 	 	  play.setToolTipText("Stop");
	     	 	 	  isPlaying = true;
	     	 	 	  
	     	 	      int pitchVal = slider.getValue();
	     	 	      int speedVal = speed.getValue();
	     	 	      int start = begin.getValue();
				      
				      song.setPitch(pitchVal);
				      song.setSpeed(speedVal);
	     	 	 	  song.setTrack(currentTrack, table.getDataVector());
	     	 	 	  track.play(song, start);
	     	 	 }
	     	 	    
	     	 }	
	
			else
			 {
			 	play.setIcon(new ImageIcon("images/play.gif"));
	     	 	play.setToolTipText("Play");
			 	isPlaying = false;
			 	
			 	track.stop();
			 }
     	 
     	 }
     	
     	if(event.getSource()==save)
     	 {
				for(int i=0;i<5;i++)
				 	song.setSelected(i, trackChecks[i].isSelected());
				 
	     	 	if(song.getNumTracksSelected() == 0)
	     	 	    JOptionPane.showMessageDialog(null,"Please select atleast single Track for Saving.","No Track error",JOptionPane.ERROR_MESSAGE);
	     	 	else
	     	 	 {
	     	 	      int pitchVal = slider.getValue();
	     	 	      int speedVal = speed.getValue();
				      
				      song.setPitch(pitchVal);
				      song.setSpeed(speedVal);
	     	 	 	  song.setTrack(currentTrack, table.getDataVector());
	     	 	 	  //track.save(song);
	     	 	 	  SaveDialog sd = new SaveDialog(this, song);
	     	 	 }

     	 } 
     	
     	if(event.getSource()==open)
     	 {
     	 	track.open(song);
     	 	table.setDataVector(song.getTrack(0));
	 	 	trackButtons[0].setBackground(Color.WHITE);
 	 	 	trackButtons[0].setForeground(Color.BLACK);
 	 	 	 
 	 	 	 for(int j=1;j<5;j++)
 	 	 	  {
 	 	 	  	trackButtons[j].setBackground(Color.GRAY);
 	 	 	    trackButtons[j].setForeground(Color.WHITE);
 	 	 	  }
     	 
     	 } 
     	
     	if(event.getSource()==calculate)
     	 {
     	 	Vector data = table.getDataVector();
     	 	Vector v = (Vector)data.elementAt(0);
    	 	double time = (double)midiData.timings.getValue((String)v.elementAt(2));
     	 	double totalTime = time;

     	 	for(int i=1;i<data.size();i++)
     	 	 {
     	 	 	v = (Vector)data.elementAt(i);
     	 	 	String status = (String)v.elementAt(0);
     	 	 	
     	 	 	if(status.equals("END"))
     	 	 	 break;
     	 	 	
     	 	 	String timeStr = (String)v.elementAt(2);
     	 	 	if(timeStr.equals("") || timeStr==null)
     	 	 	  totalTime+= time;
     	 	 	
     	 	 	else
     	 	 	 {
     	 	 	 	time = (double)midiData.timings.getValue(timeStr);
     	 	 	 	totalTime+= time;
     	 	 	 	System.out.println("Total time = "+totalTime+"\tTime = "+time);
     	 	 	 }
     	 	 	 
     	 	 }

	 	 	java.text.NumberFormat nf = java.text.NumberFormat.getInstance();
	 	 	nf.setMaximumFractionDigits(4);
     	 	totalTime = totalTime/24.0;
     	 	
     	 	double num = Double.parseDouble(numField.getText());
     	 	double result = totalTime  % num;
     	 	System.out.println("Total time = "+totalTime+"\tResult = "+result);
     	 	
     	 	label.setText(nf.format(result));
     	 } 
     }
	
	private void positionSlider()
	 {
	 	int position = table.getSelectedRow();
	 	double percentage = 0;
	 	double max = 0;
	 	
	 	String str = (String)table.getValueAt(0,2);
	 	double value = midiData.timings.getValue(str);
	 	
	 	for(int i=1;i<table.getRowCount();i++)
	 	 {
	 	 	str = (String)table.getValueAt(i,2);
	 	 	
	 	 	if(((String)table.getValueAt(i,0)).equals("END"))
	 	 	 break;
	 	 	 
	 	 	if(str.equals("") || str.equals(null))
	 	 	 {
	 	 	 }
	 	 	
	 	 	else
	 	 	 value = midiData.timings.getValue(str);
	 	 	  
	 	 	
 	 	 	max+= value;
 	 	 	
 	 	 	if(i<=position)
 	 	 	 percentage+= value;
	 	 }
	 	 
	 	percentage = percentage/max * 100;
	 	
	 	System.out.println("position = "+percentage);
    	begin.setValue((int)percentage);
	 	
	 }

	public void onNoteEvent(NoteEvent nEvent)
	{
		int row = table.getSelectedRow();
		table.setValueAt(nEvent.getNote(), row, 1);
		table.setValueAt(nEvent.getTiming(), row, 2);
		
		if(row<table.getRowCount()-1)
			table.changeSelection(row+1, 0, false, false);
		else
		    table.changeSelection(row, 0, false, false);
	}
	
	public static void main(String[] args)
	 {
		new MyMidi();
	 }	
 }
