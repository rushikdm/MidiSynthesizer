package mymidi.midilayer;

import javax.sound.midi.*;
import java.util.Vector;
import java.io.*;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.Color;


public class MyTrack
 {
    Sequencer sequencer;
    MidiData midiData;
    
 	public MyTrack()
 	 {
 	 	midiData = new MidiData();
 	 	setupMidi();
 	 }
 	 
 	 private void setupMidi()
 	  {
 	  	    Synthesizer synthesizer = null;

 	      try {
            if (synthesizer == null) {
                if ((synthesizer = MidiSystem.getSynthesizer()) == null) {
                    System.out.println("getSynthesizer() failed!");
                    return;
                }
            } 
            synthesizer.open();
            sequencer = MidiSystem.getSequencer();
        } catch (Exception ex) { ex.printStackTrace(); return; }
        
	 }
 	
	private Sequence getSequence(MidiSong song)
	 {
	 	Sequence seq=null;
	 	int resolution = 30 * song.getSpeed()/100;
	 	int numTracksSelected = song.getNumTracksSelected();
	 	int totalNumTracks = song.getTotalNumTracks();
	 	Track[] tracks = new Track[numTracksSelected];
	 	
	 	try
	 	{
	 		seq = new Sequence(Sequence.PPQ, resolution);
	 		int num = 0;
	 		
	 		for(int i=0;i<totalNumTracks;i++)
			 {
			 	if(song.isSelected(i))
			 		{
			 			tracks[num] = seq.createTrack();
			 	        addDataToTrack(tracks[num], song.getTrack(i), song.getPitch(), song.getSpeed());
			 	        num = num+1;
			 		}
			 }
	 	}
		catch(Exception ex) { ex.printStackTrace(); }
		
		return seq;
	}		
	
	private void addDataToTrack(Track track, Vector data, int pitch, int speedVal)
	{
	 	Vector v = (Vector)data.elementAt(0);
	 	String inst = (String)v.elementAt(0);
	 	String note = (String)v.elementAt(1);
	 	String tm = (String)v.elementAt(2);
	 	String vol = (String)v.elementAt(3);
	 	
	 	int instInt = midiData.instruments.getValue(inst);
	 	int noteInt = midiData.notes.getValue(note);
	 	int timeInt = midiData.timings.getValue(tm);
	 	int volInt  = midiData.volumes.getValue(vol);

	 	try
	 	 {
	        ShortMessage message = new ShortMessage();
	        message.setMessage(ShortMessage.PROGRAM_CHANGE, instInt,0);
	        MidiEvent event = new MidiEvent(message, 0);
	        track.add(event);
         }
       catch (Exception ex) { ex.printStackTrace(); }
	 	
	 	long time=1;
	 	
 	 	try
 	 	 {
	 	 	ShortMessage message1 = new ShortMessage();
	 	 	message1.setMessage(ShortMessage.NOTE_ON, noteInt + pitch, volInt);
	 	 	MidiEvent event1 = new MidiEvent(message1, time);
	        track.add(event1);
	        time+=(long)timeInt;
	        
	        ShortMessage message2 = new ShortMessage();
	 	 	message2.setMessage(ShortMessage.NOTE_OFF, noteInt + pitch, volInt);
	        MidiEvent event2 = new MidiEvent(message2, time);
	        track.add(event2);
         }
       catch (Exception ex) { ex.printStackTrace(); }
	 	
	 	for(int i=1;i<data.size();i++)
	 	 {
	 	 	Vector vect = (Vector)data.elementAt(i);
	 	 	String newInst = (String)vect.elementAt(0);
		 	note = (String)vect.elementAt(1);
		 	tm = (String)vect.elementAt(2);
		 	vol = (String)vect.elementAt(3);

			if(newInst=="END")
			 return;
	 	 	
	 	 	if(!newInst.equals(inst))
	 	 	 {
	 	 	 	if(newInst.equals("") || newInst==null)
	 	 	 	 {
	 	 	 	 	
	 	 	 	 }
	 	 	 	
	 	 	 	else
	 	 	 	{
			 	try
			 	 {
			        ShortMessage message = new ShortMessage();
			        message.setMessage(ShortMessage.PROGRAM_CHANGE, midiData.instruments.getValue(newInst),0);
			        MidiEvent event = new MidiEvent(message, time);
			        track.add(event);
			        inst = newInst;
		         }
		         
		       catch (Exception ex) { ex.printStackTrace(); }
		       }
	 	 	 }
			
			if(note.equals("") || note==null)
			 {
				
			 }
			
			else
	 		  noteInt = midiData.notes.getValue(note);
	 		
	 		if(tm.equals("") || tm==null)
	 		 {
	 		 	
	 		 }
	 		 
	 		 else
	 		  timeInt = midiData.timings.getValue(tm);
	 		
	 		if(vol.equals("") || vol==null)
	 		 {
	 		 	
	 		 }
	 		
	 		else 
	 		  volInt = midiData.volumes.getValue(vol);
			
	 	 	try
	 	 	 {
		 	 	ShortMessage message1 = new ShortMessage();
		 	 	message1.setMessage(ShortMessage.NOTE_ON, noteInt + pitch, volInt);
		 	 	MidiEvent event1 = new MidiEvent(message1, time);
		        track.add(event1);
		        time+=(long)timeInt;
		        
		        ShortMessage message2 = new ShortMessage();
		 	 	message2.setMessage(ShortMessage.NOTE_OFF, noteInt + pitch, volInt);
		        MidiEvent event2 = new MidiEvent(message2, time);
		        track.add(event2);
	         }
	       catch (Exception ex) { ex.printStackTrace(); }
	 	 	 
	 	 }
	 	 
	 	 return;
	 } 
	
	public void play(MidiSong song, int start)
	 {
           Sequence sequence = getSequence(song);

        try {
        		long length = sequence.getMicrosecondLength();
        		length = length / 100 * start;
        		sequencer.open();
       			sequencer.setSequence(sequence);
       			sequencer.setMicrosecondPosition(length);
       			sequencer.setTempoFactor((float)(song.getSpeed()/100.0));
            } 
            catch (Exception ex) { ex.printStackTrace(); }
			
			sequencer.start();
	 } 

	public void stop()
	 {
	 	sequencer.stop();
	 }
	 
	public void save(File file, MidiSong song)
	 {
	 	Sequence sequence = getSequence(song);

        try {
            int[] fileTypes = MidiSystem.getMidiFileTypes(sequence);
            if (fileTypes.length == 0) {
                System.out.println("Can't save sequence");
            } else {
                if (MidiSystem.write(sequence, fileTypes[0], file) == -1) {
                    throw new IOException("Problems writing to file");
                } 
            }
        } catch (SecurityException ex) { 
            JOptionPane.showMessageDialog(null,"Error in saving the file!","Error",JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) { 
            ex.printStackTrace(); 
        }
    }
    
   public void open(MidiSong song)
    {
    	Sequence seq = null;
    	
        try {
            File file = new File(System.getProperty("user.dir"));
            JFileChooser fc = new JFileChooser(file);
            fc.setFileFilter(new javax.swing.filechooser.FileFilter() {
                public boolean accept(File f) {
                    if (f.isDirectory()) {
                        return true;
                    }
                    return false;
                }
                public String getDescription() {
                    return "Open .mid files.";
                }
            });
            if (fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                	seq = MidiSystem.getSequence(fc.getSelectedFile());
            }
        } catch (SecurityException ex) { 
            JOptionPane.showMessageDialog(null,"Error in saving the file!","Error",JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } catch (Exception ex) { 
            ex.printStackTrace();
        }
    	
    	Track[] tracks = seq.getTracks();
    	int numTracks = tracks.length;
    	
    	for(int i=0;i<numTracks;i++)
    	 	fillDataFromTrack(i, song, tracks[i]);
    	
    }
    
    private void fillDataFromTrack(int num, MidiSong song, Track track) 
    {
    	Vector data = new Vector();
    	Vector vec = new Vector();
    	
	 	MidiEvent event = track.get(0);
	 	ShortMessage message = (ShortMessage)event.getMessage();
	 	int data1 = message.getData1();
    	
    	if(message.getCommand()==ShortMessage.PROGRAM_CHANGE)
    	 vec.addElement(midiData.instruments.getString(data1));

	 	event = track.get(1);
	 	long tick1 = event.getTick();
	 	message = (ShortMessage)event.getMessage();
	 	data1 = message.getData1();
	 	int data2 = message.getData2();

	 	event = track.get(2);
	 	long tick2 = event.getTick();
	 	String tmStr = midiData.timings.getString((int)(tick2-tick1));
	 	String ntStr = midiData.notes.getString(data1);
	 	String vlStr = midiData.volumes.getString(data2);
	 	
	 	message = (ShortMessage)event.getMessage();
    	
	 	vec.addElement(ntStr);
	 	vec.addElement(tmStr);
	 	vec.addElement(vlStr);
    	
    	data.addElement(vec);
		boolean check=false;
    	
    	int i=3;
    	while(i<track.size()-1)
    	 {
		 	MidiEvent event1 = track.get(i);
		 	ShortMessage message1 = (ShortMessage)event1.getMessage();
    	 	
	    	if(message1.getCommand()==ShortMessage.PROGRAM_CHANGE)
	    	 {
	    	 	check = true;
	    	 	vec = new Vector();
	    	 	vec.addElement(midiData.instruments.getString(message1.getData1()));
	    	 	i++;
	    	 }
	    	
	    	else 
	    	 {
	    	 	if(!check)
	    	 	 {
	    	 	 	vec = new Vector();
	    	 	 	vec.addElement("");
	    	 	 }
	    	 	 
			 	tick1 = event1.getTick();
			 	data1 = message1.getData1();
			 	data2 = message1.getData2();
	    	 	
	    	 	i=i+1;	
			 	event1 = track.get(i);
			 	tick2 = event1.getTick();
			 	message1 = (ShortMessage)event1.getMessage();
		    	
		    	if(!ntStr.equals(midiData.notes.getString(data1)))
		    	 {
		    	 	ntStr = midiData.notes.getString(data1);
		    	 	vec.addElement(ntStr);
		    	 }
			 	  
				
				else
				 vec.addElement("");
				 
		    	if(!tmStr.equals(midiData.timings.getString((int)(tick2-tick1))))
		    	 {
		    	 	tmStr = midiData.timings.getString((int)(tick2-tick1));
			 	    vec.addElement(tmStr);
		    	 }

				
				else
				 vec.addElement("");
				 
			 	if(!vlStr.equals(midiData.volumes.getString(data2)))
			 	 {
			 	 	vlStr = midiData.volumes.getString(data2);
			 	 	vec.addElement(vlStr);
			 	 }
			 	  
				
				else
				 vec.addElement("");
				 
			 	data.addElement(vec);
			 	
	    	 	check = false;
	    	 	i++;
	    	 } 	
    	 }
    	 
    	 Vector v = new Vector();
    	 v.addElement("END");
    	 v.addElement("");
    	 v.addElement("");
    	 v.addElement("");
    	 data.addElement(v);     	 
    	 
    	 for(i=0;i<500;i++)
    	  {
    	  	v = new Vector();
    	  	
    	  	for(int j=0;j<4;j++)
    	  	 v.addElement("");
    	  	
    	  	data.addElement(v); 
    	  }
    	 
		song.setTrack(num, data);
     }
 }
