package mymidi.midilayer;

public class MidiData 
{
	/*
	 * Instruments
	 */
		private String[] instStr = {"Piano","Harpsi Chord","Accordion","Nylon Str Guitar","Fretless Bass","Cello","Synth Strings 1","Bassoon","Shanai","END"};
		private int[] instValues = {0,6,20,24,35,42,50,70,111}; 
		public Data instruments;
	/*
	 * Notes
	 */
		private String[] noteStr = {"GA---","Ma---","MA---","P---","Da---","DA---","Ni---","NI---","S--","Re--","RE--","Ga--","GA--","Ma--","MA--","P--","Da--","DA--","Ni--","NI--","S-","Re-","RE-","Ga-","GA-","Ma-","MA-","P-","Da-","DA-","Ni-","NI-","S","Re","RE","Ga","GA","Ma","MA","P","Da","DA","Ni","NI","S*","Re*","RE*","Ga*","GA*","Ma*","MA*","P*","Da*","DA*","Ni*","NI*","S**","Re**","RE**","Ga**","GA**","Ma**","MA**","P**","Da**","DA**","Ni**","NI**","S***","Re***","RE***","Ga***"}; 
		private int[] noteValues = {24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95};
		public Data notes;

	/*
	 * Timings
	 */
		private String[] timeStr = {"4","2","1","7/8","3/4","2/3","1/2","1/3","1/4","1/8"}; 
		private int[] timeValues = {96,48,24,21,18,16,12,8,6,3};
		public Data timings;
		
	/*
	 * Volumes
	 */
    	private String[] volStr = {"0","1","2","3","4","5","6","7"}; 
    	private int[] volValues = {0,13,26,39,52,65,78,91};
 	 	public Data volumes;

	public MidiData()
	{
		initialize();
	}
		
	private void initialize()
	{
		instruments = new Data(instStr, instValues);
		
		notes       = new Data(noteStr, noteValues);

		timings     = new Data(timeStr, timeValues);
 	 	
		volumes     = new Data(volStr, volValues);
	}
	
	public class Data
	 {
	 	String[] strArray;
	 	int[] values;
	 	
	 	public Data(String[] str, int[] values)
	 	 {
	 	 	this.strArray = str;
	 	 	this.values = values;
	 	 }
	 	
	 	public String[] getStrArray()
	 	 {
	 	 	return strArray;
	 	 }
	 	
	 	public int[] getIntArray()
	 	 {
	 	 	return values;
	 	 } 
	 	
	 	public String getString(int value) 
	 	 {
		 	String result = "";
		 	
		 	for(int i=0;i<values.length;i++)
		 	 {
		 	 	if(value==values[i])
		 	 	 {
		 	 	 	result = strArray[i];
		 	 	 	break;
		 	 	 }
		 	 	 
		 	 }
		 	
		 	return result; 
	 	 	
	 	 }
	 	
	 	public int getValue(String s)
	 	 {
		 	int result = -1;
		 	
		 	for(int i=0;i<values.length;i++)
		 	 {
		 	 	if(s.equals(strArray[i]))
		 	 	 {
		 	 	 	result = values[i];
		 	 	 	break;
		 	 	 }
		 	 	 
		 	 }
		 	
		 	return result; 
	 	 	
	 	 }
	 }  	

}
