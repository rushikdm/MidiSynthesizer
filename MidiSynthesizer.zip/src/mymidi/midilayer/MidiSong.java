package mymidi.midilayer;

import java.util.Vector;

public class MidiSong
 {
 	MidiTrack[] tracks;
	int numTracks;
	int pitch;
	int speed;
	
	public MidiSong(int numTracks)
	 {
	 	this.numTracks = numTracks;
		tracks = new MidiTrack[numTracks];
		
		for(int i=0;i<numTracks;i++)
		 {
		 	tracks[i] = new MidiTrack();
		 }
	 }	
	
	public int getTotalNumTracks()
	 {
	 	return numTracks;
	 }
	 
	public int getNumTracksSelected()
	{
		int num = 0;
		for(int i=0;i<numTracks;i++)
		 {
		 	if(tracks[i].isSelected())
		 	  num = num+1;
		 }
		
		return num;
	} 
	
	public void setPitch(int pitch)
	{
		this.pitch = pitch;
	}

	public int getPitch()
	{
		return pitch;
	}
	
	public void setSpeed(int speed)
	{
		this.speed = speed;
	}

	public int getSpeed()
	{
		return speed;
	}

	public boolean isSelected(int i)
	{
		return tracks[i].isSelected();
	}
    
    public Vector getTrack(int i)	
    {
    	return tracks[i].getData();
    }
    
	public void setSelected(int i, boolean bool)
	{
		tracks[i].setSelected(bool);
	}
    
    public void setTrack(int i, Vector vect)	
    {
    	tracks[i].setData(vect);
    }

	public class MidiTrack
	 {
		Vector trackData;
		boolean isSelected = false;
		
		public MidiTrack()
		{
			trackData = new Vector();
			
			for(int i=0;i<500;i++)
			 {
			 	 Vector v = new  Vector();
			 	 
			 	 for(int j=0;j<4;j++)
			 	  	 v.addElement("");
			 	 
			 	 trackData.addElement(v);
			 }
		}
		
		public Vector getData()
		 {
			return trackData;
		 } 
		
		public boolean isSelected()
		 {
		 	return isSelected;
		 }
		
		public void setData(Vector vector)
		 {
		 	this.trackData = vector;
		 }
		
		public void setSelected(boolean b)
		 {
		 	this.isSelected = b;
		 }

	 }
	 
 }
